﻿namespace escola_system
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtNome = new TextBox();
            txtNascimento = new MaskedTextBox();
            txtCurso = new TextBox();
            txtTelefone = new TextBox();
            btnCadastrar = new Button();
            btnListar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            btnLimpar = new Button();
            dataGridAlunos = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridAlunos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(77, 61);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(54, 18);
            label1.TabIndex = 0;
            label1.Text = "Nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(77, 103);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(95, 18);
            label2.TabIndex = 1;
            label2.Text = "Nascimento:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(77, 145);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(54, 18);
            label3.TabIndex = 2;
            label3.Text = "Curso:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(77, 189);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(70, 18);
            label4.TabIndex = 3;
            label4.Text = "Telefone:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(190, 58);
            txtNome.MaxLength = 100;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(341, 26);
            txtNome.TabIndex = 4;
            // 
            // txtNascimento
            // 
            txtNascimento.Location = new Point(190, 100);
            txtNascimento.Mask = "00/00/0000";
            txtNascimento.Name = "txtNascimento";
            txtNascimento.Size = new Size(341, 26);
            txtNascimento.TabIndex = 5;
            // 
            // txtCurso
            // 
            txtCurso.Location = new Point(190, 142);
            txtCurso.MaxLength = 100;
            txtCurso.Name = "txtCurso";
            txtCurso.Size = new Size(341, 26);
            txtCurso.TabIndex = 6;
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(190, 186);
            txtTelefone.MaxLength = 20;
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(341, 26);
            txtTelefone.TabIndex = 7;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(56, 256);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(91, 28);
            btnCadastrar.TabIndex = 8;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnListar
            // 
            btnListar.Location = new Point(167, 256);
            btnListar.Name = "btnListar";
            btnListar.Size = new Size(75, 28);
            btnListar.TabIndex = 9;
            btnListar.Text = "Listar";
            btnListar.UseVisualStyleBackColor = true;
            btnListar.Click += btnListar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(263, 256);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(75, 28);
            btnEditar.TabIndex = 10;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(360, 256);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(75, 28);
            btnExcluir.TabIndex = 11;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(456, 256);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(75, 28);
            btnLimpar.TabIndex = 12;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // dataGridAlunos
            // 
            dataGridAlunos.AllowUserToAddRows = false;
            dataGridAlunos.AllowUserToDeleteRows = false;
            dataGridAlunos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridAlunos.Location = new Point(56, 308);
            dataGridAlunos.Name = "dataGridAlunos";
            dataGridAlunos.ReadOnly = true;
            dataGridAlunos.RowHeadersVisible = false;
            dataGridAlunos.Size = new Size(475, 221);
            dataGridAlunos.TabIndex = 13;
            dataGridAlunos.CellClick += dataGridAlunos_CellClick;
            dataGridAlunos.CellDoubleClick += dataGridAlunos_CellDoubleClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(597, 559);
            Controls.Add(dataGridAlunos);
            Controls.Add(btnLimpar);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnListar);
            Controls.Add(btnCadastrar);
            Controls.Add(txtTelefone);
            Controls.Add(txtCurso);
            Controls.Add(txtNascimento);
            Controls.Add(txtNome);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridAlunos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtNome;
        private MaskedTextBox txtNascimento;
        private TextBox txtCurso;
        private TextBox txtTelefone;
        private Button btnCadastrar;
        private Button btnListar;
        private Button btnEditar;
        private Button btnExcluir;
        private Button btnLimpar;
        private DataGridView dataGridAlunos;
    }
}
