using MySql.Data.MySqlClient;

namespace escola_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = txtNome.Text;
                string dataNascimento = txtNascimento.Text;
                string curso = txtCurso.Text;
                string telefone = txtTelefone.Text;

                if (nome != "" && dataNascimento != "" && curso != "" && telefone != "")
                {
                    string conexaoBanco = "Server=localhost; Database=escola; Uid=root; Pwd=''";
                    MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                    conexao.Open();

                    DateTime dataMysqlFormat = Convert.ToDateTime(dataNascimento);
                    string dataNascimentoFormatada = dataMysqlFormat.ToString("yyyy-MM-dd");

                    string cadastro = "insert into alunos (nome, dataNascimento, curso, telefone) values (@nome, @dataNascimento, @curso, @telefone);";

                    MySqlCommand comando = new MySqlCommand(cadastro, conexao);
                    comando.Parameters.AddWithValue("@nome", nome);
                    comando.Parameters.AddWithValue("@dataNascimento", dataNascimentoFormatada);
                    comando.Parameters.AddWithValue("@curso", curso);
                    comando.Parameters.AddWithValue("@telefone", telefone);

                    comando.ExecuteNonQuery();
                    MessageBox.Show("Aluno cadastrado com sucesso!");

                    txtNome.Clear();
                    txtNascimento.Clear();
                    txtCurso.Clear();
                    txtTelefone.Clear();
                }
                else
                {
                    MessageBox.Show("Preencha os campos corretamente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao realizar cadastro!" + ex.Message);
            }
        }
    }
}
